<?php
/*Configuration Settings*/

/*MySQL Settings*/
/*Database name*/
define('DB_NAME', 'YOUR DATABASE NAME HERE');

/*Database user*/
define('DB_USER', 'YOUR USERNAME HERE');

/*Database user password*/
define('DB_PASSWORD', 'YOUR PASSWORD HERE');

/* Chances are you won't need to change the following three
settings. Only do so if you know what you're doing.*/

/*Database host*/
define('DB_HOST', 'localhost');

/*Database character set*/
define('DB_CHARSET', 'utf8');

/*Database collation*/
define('DB_COLLATE', '');

/*RECAPTCHA Settings*/
/*Public Key*/
define('R_PUBLIC', 'YOUR RECAPTCHA PUBLIC KEY HERE');

/*Private Key*/
define('R_PRIVATE', 'YOUR RECAPTCHA PRIVATE KEY HERE');

?>

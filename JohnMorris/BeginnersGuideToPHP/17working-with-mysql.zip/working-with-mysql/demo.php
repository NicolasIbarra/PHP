<form action="process.php" method="post" />
<p>Input 1: <input type="text" name="input1" /></p>
<p>Input 2: <input type="text" name="input2" /></p>
<input type="submit" value="Submit" />
</form>
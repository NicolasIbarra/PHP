<?php
//Constants

//Database Information

/* Login URL
 * The URL to the default login page.
 */
if ( !defined('J_LOGIN_URL') )
	define('J_LOGIN_URL', JURL . 'login.php');
?>
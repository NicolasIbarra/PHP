<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<title>Price Comparison Site</title>
		<!--Stylesheets-->
		<link rel="stylesheet" type="text-css" href="<?php echo get_theme_url($theme); ?>style.css" media="screen" />
	</head>

	<body>
		<div id="wrapper">
			<div id="logo">
				<h1>Price Comparison Site</h1>
			</div>
			
			<div id="navigation">
				<ul class="nav" id="main-nav">
					<li><a href="<?php echo JURL; ?>">Home</a></li>
				</ul>
			</div>
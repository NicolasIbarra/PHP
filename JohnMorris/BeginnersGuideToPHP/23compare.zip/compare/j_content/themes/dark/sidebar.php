<div id="sidebar">
	<h3>Categories</h3>
	<?php $categories = list_categories(); print_r($categories); ?>
</div>
<?php
/* Theme Functions
 *
 * Here you can create custom functions for your theme. These functions are
 * loaded before any theme files are loaded.
 */
?>
<?php
/* Theme Functions */

//Globalize all our classes
global $j, $ja, $jdb, $jaNav;

//Set our theme
$theme = 'default';

?>
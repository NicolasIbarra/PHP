<?php
	//Load only the required amin files in order
	require_once(dirname(__FILE__) . '/class-admin-functions.php');
	require_once(dirname(__FILE__) . '/class-navigation.php');
?>
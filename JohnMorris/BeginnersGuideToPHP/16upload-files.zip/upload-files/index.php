<form enctype="multipart/form-data" action="process.php" method="post">
	<label for="uploadedfile">Choose a file to upload: </label>
	<input type="file" name="uploadedfile" />
	<input type="submit" value="Upload File" />
</form>
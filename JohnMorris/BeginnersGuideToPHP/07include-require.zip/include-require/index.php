<!DOCTYPE HTML PUBLIC "-/W3C//DTD HTML 4.01 Transitional//EN" http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Example</title>
	</head>
	<body style="width: 960px; margin: 25px auto 0;">
		<?php 
			include('included.php'); 
			include_once('included.php'); 
			require('included.php'); 
			require_once('included.php'); 
		?>
	</body>
</html>
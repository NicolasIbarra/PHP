<?php
	echo '<p>Included file</p>';
?>
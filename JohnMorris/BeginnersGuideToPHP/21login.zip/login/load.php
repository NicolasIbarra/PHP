<?php
	//Load all the required files in order
	require_once(dirname(__FILE__) . '/config.php');
	require_once(dirname(__FILE__) . '/j_includes/db.php');
	require_once(dirname(__FILE__) . '/j_includes/class.php');
?>